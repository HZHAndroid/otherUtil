// 用户模块 actionTypes

export const GET_AGE = "get_age";
export const GET_AGE_SUCCESS = "get_age_success";
