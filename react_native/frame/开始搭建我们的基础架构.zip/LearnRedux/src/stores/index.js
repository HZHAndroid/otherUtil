import {createStore, applyMiddleware, compose} from 'redux'

//引入异步操作
import thunk from 'redux-thunk';
import createLogger from 'redux-logger';

//引入所有的reducers,切记要在index.js封装下(这里已经是合并后的结果，所以可以直接用来创建 store)
import reducers from '../reducers'

// 定义一个数组存储中间件
const middlewares = [thunk, createLogger];

const configureStore = (initialState) => {
    /**
     reducers : 是多个 reduce合并后的结果
     initialState : 初始化默认值
     compose: 中间件
     */

    // 创建 store
    return createStore(
        reducers,
        initialState,
        compose(
            applyMiddleware(...middlewares)
        )
    );
};

//创建store
const store = configureStore();

//配置store信息
export default store
